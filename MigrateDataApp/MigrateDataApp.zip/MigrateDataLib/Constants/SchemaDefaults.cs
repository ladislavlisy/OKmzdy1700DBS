﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MigrateDataLib.Constants
{
    class SchemaDefaults
    {

        public const string EMPTY_STRING = "";
        public const string QUOTES = "\"";
        public const string USER_NAME = "okmzdy";
        public const string OWNER_NAME = "oksystem";
        public const string FOXBASE_DRIVER = "FoxPro 2.0;";
    }
}
